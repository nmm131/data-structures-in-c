// Program P7.x
     #include <stdio.h>
     #include <stdlib.h>
     #include <string.h>

     #define MaxWordSize 20
     #define MaxVertices 50
     #define MaxEdges 100
     #define White 'w'
     #define Gray 'g'
     #define Black 'b'
     #define Infinity 99999

     typedef struct gEdge {
        int child, weight; //'child' is the location of the child vertex
        struct gEdge *nextEdge;
     } GEdge, *GEdgePtr;

     typedef struct {
        char id[MaxWordSize+1], colour;
        int parent, cost, discover, finish, inDegree;
        GEdgePtr firstEdge;
     } GVertex;

     typedef struct graph {
        int numV;
        GVertex vertex[MaxVertices+1];
     } *Graph;

     typedef struct {
        int parent, child, weight;
     } UndirectedEdge;
     int main() {
        int numVertices;
        Graph newGraph(int);
        void buildGraph(FILE *, Graph);
        void Kruskal(Graph);

        FILE * in = fopen("kruskal.in", "r");

        fscanf(in, "%d", &numVertices);
        Graph G = newGraph(numVertices);
        buildGraph(in, G);
        Kruskal(G);
        fclose(in);
     } // end main

     void Kruskal(Graph G) {
        int getSortedEdges(Graph, UndirectedEdge[], int);
        int getSetID(int[], int);
        void setUnion(int[], int, int);
        void printKruskalMST(Graph, UndirectedEdge[], int);
        UndirectedEdge edgeList[MaxEdges];
        int P[MaxVertices+1]; //P used to implement disjoint subsets

        for (int h = 1; h <= G -> numV; h++) P[h] = 0;

        int numEdges = getSortedEdges(G, edgeList, MaxEdges);
        UndirectedEdge MST[MaxEdges];
        int t = 0; //used to index MST
        for (int h = 0; h < numEdges; h++) {
           int xRoot = getSetID(P, edgeList[h].parent);
           int yRoot = getSetID(P, edgeList[h].child);
           if (xRoot != yRoot) {
              MST[t++] = edgeList[h];
              setUnion(P, xRoot, yRoot);
           } //end if
        } //end for
        printKruskalMST(G, MST, t);
     } //end Kruskal

     void printKruskalMST(Graph G, UndirectedEdge MST[], int n) {
     //print the n edges in the MST and the total cost
        int cost = 0;
        printf("\nThe edges/weights in the MST are\n\n");
        for (int h = 0; h < n; h++) {
           printf("(%s, %s): %d\n", G -> vertex[MST[h].parent].id,
                    G -> vertex[MST[h].child].id, MST[h].weight);
           cost += MST[h].weight;
        }
        printf("\nCost of tree: %d\n", cost);
     } //end printKruskalMST

     int getSetID(int P[], int x) {
        while (P[x] != 0) x = P[x];
        return x;
     } //end getSetID

     void setUnion(int P[], int x, int y) {
        int xi = getSetID(P, x);
        int yi = getSetID(P, y);
        if (xi != yi) P[xi] = yi;
     } //end setUnion

     int getSortedEdges(Graph G, UndirectedEdge list[], int max) {
        int inEdgeList(int, int, UndirectedEdge[], int);
        UndirectedEdge newUndirectedEdge(int, int, int);
        void sortEdges(UndirectedEdge[], int);
        int numEdges = 0;

        for (int h = 1; h <= G -> numV; h++) {
           GEdgePtr p = G -> vertex[h].firstEdge;
           while (p != NULL) {
              if (!inEdgeList(h, p -> child, list, numEdges)) {
                 if (numEdges == max) {
                    printf("\nToo many edges; exceeds %d\n", max);
                    exit(1);
                 }
                 list[numEdges] = newUndirectedEdge(h, p -> child, p -> weight);
                 numEdges++;
              } //end if
              p = p -> nextEdge;
           } //end while
        } //end for
        sortEdges(list, numEdges);
        return numEdges;
     } //end getSortedEdges

     UndirectedEdge newUndirectedEdge(int p, int c, int w) {
        UndirectedEdge temp;
        temp.parent = p;
        temp.child = c;
        temp.weight = w;
        return temp;
     } //end newUndirectedEdge

     int inEdgeList(int u, int v, UndirectedEdge list[], int n) {
     //search for edge (u, v) in list[0..n-1]
        for (int h = 0; h < n; h++)
           if (u == list[h].child && v == list[h].parent) return 1;
        return 0;
     } //end inEdgeList

     void sortEdges(UndirectedEdge list[], int n) {
     //sort list[0] to list[n-1] by increasing weight
        int i, j;
        for (i = 1; i < n; i++) {
           UndirectedEdge hold = list[i];
           j = i - 1;
           while (j >= 0 && hold.weight < list[j].weight) {
              list[j+1] = list[j];
              j = j - 1;
           }
           list[j+1] = hold;
        } //end for
     } //end sortEdges

     Graph newGraph(int n) {
        if (n > MaxVertices) {
           printf("\nToo big. Only %d vertices allowed.\n", MaxVertices);
           exit(1);
        }
        Graph p = (Graph) malloc(sizeof(struct graph));
        p -> numV = n;
        return p;
     } //end newGraph

     void buildGraph(FILE * in, Graph G) {
        int numEdges, weight;
        GVertex newGVertex(char[]);
        void addEdge(char[], char[], int, Graph);
        char nodeID[MaxWordSize+1], adjID[MaxWordSize+1];
        for (int h = 1; h <= G -> numV; h++) {
           G -> vertex[h] = newGVertex("");      //create a vertex node
           fscanf(in, "%s", G -> vertex[h].id);   //read the name into id
        }
        for (int h = 1; h <= G -> numV; h++) {
           fscanf(in, "%s %d", nodeID, &numEdges); //parent id and numEdges
           for (int k = 1; k <= numEdges; k++) {
              fscanf(in, "%s %d", adjID, &weight); //get child id and weight
              addEdge(nodeID, adjID, weight, G);
           }
        }
     } //end buildGraph

     GVertex newGVertex(char name[]) {
        GVertex temp;
        strcpy(temp.id, name);
        temp.firstEdge = NULL;
        return temp;
     }

     void addEdge(char X[], char Y[], int weight, Graph G) {
        GEdgePtr newGEdge(int, int);
        //add an edge X -> Y with a given weight
        int h, k;
        //find X in the list of nodes; its location is h
        for (h = 1; h <= G -> numV; h++) if (strcmp(X, G -> vertex[h].id) == 0) break;

        //find Y in the list of nodes; its location is k
        for (k = 1; k <= G-> numV; k++) if (strcmp(Y, G -> vertex[k].id) == 0) break;

        if (h > G -> numV || k > G -> numV) {
           printf("No such edge: %s -> %s\n", X, Y);
           exit(1);
        }

        GEdgePtr ep = newGEdge(k, weight); //create edge vertex
        // add it to the list of edges, possible empty, from X;
        // it is added so that the list is in order by vertex id
        GEdgePtr prev, curr;
        prev = curr = G -> vertex[h].firstEdge;
        while (curr != NULL && strcmp(Y, G -> vertex[curr -> child].id) > 0) {
           prev = curr;
           curr = curr -> nextEdge;
        }

        if (prev == curr) {
           ep -> nextEdge = G -> vertex[h].firstEdge;
           G -> vertex[h].firstEdge = ep;
        }
        else {
           ep -> nextEdge = curr;
           prev -> nextEdge = ep;
        }
     } //end addEdge

     GEdgePtr newGEdge(int c, int w) {
     //return a pointer to a new GEdge node
        GEdgePtr p = (GEdgePtr) malloc(sizeof (GEdge));;
        p -> child = c;
        p -> weight = w;
        p -> nextEdge = NULL;
        return p;
     }
