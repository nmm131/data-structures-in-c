// Program P7.2
     #include <stdio.h>
     #include <stdlib.h>

     #define MaxItems 50
     #define White 'w'
     #define Gray 'g'
     #define Black 'b'

     typedef struct {
        int nv; //index of a graph vertex
     } StackData;

     #include <stack.h>

     typedef struct gEdge {
        int child, weight; //'child' is the location of the child vertex
        struct gEdge *nextEdge;
     } GEdge, *GEdgePtr;

     typedef struct {
        int id, parent, cost, discover, finish, inDegree;
        char colour;
        GEdgePtr firstEdge;
     } GVertex;

     typedef struct graph {
        int numV;
        GVertex vertex[MaxItems+1];
     } *Graph;

     int main() {
        int numItems, numRequirements;
        void printRequirements(Graph);
        Graph newGraph(int);
        void buildTopSortGraph(FILE *, Graph, int);
        void topologicalSort(Graph);

        FILE * in = fopen("topsort.in", "r");
        fscanf(in, "%d %d", &numItems, &numRequirements);
        if (numItems > MaxItems) {
           printf("\nToo many items. Only %d allowed.\n", MaxItems);
           exit(1);
        }
        Graph G = newGraph(numItems);
        buildTopSortGraph(in, G, numRequirements);
        printRequirements(G);
        topologicalSort(G);
        fclose(in);
     } // end main

     Graph newGraph(int n) {
        Graph p = (Graph) malloc(sizeof(struct graph));
        p -> numV = n;
        return p;
     } //end newGraph

     void buildTopSortGraph(FILE * in, Graph G, int numRequirements) {
        GVertex newGVertex(int);
        void addEdge(int, int, int, Graph);
        int preID, postID;
        for (int h = 1; h <= G -> numV; h++) {
           G -> vertex[h] = newGVertex(-1); //create a vertex node
           G -> vertex[h].id = h;           //IDs run from 1 to h
        }
        for (int h = 1; h <= numRequirements; h++) {
           fscanf(in, "%d %d", &preID, &postID); //get a requirement
           addEdge(preID, postID, 1, G);  //weights are not important; set to 1
        }
     } //end buildTopSortGraph

     GVertex newGVertex(int name) {
        GVertex temp;
        temp.id = name;
        temp.firstEdge = NULL;
        return temp;
     }

     void addEdge(int X, int Y, int weight, Graph G) {
        GEdgePtr newGEdge(int, int);
        //add an edge X -> Y with a given weight

        GEdgePtr ep = newGEdge(Y, weight); //create edge vertex
        // add it to the list of edges, possible empty, from X;
        // it is added so that the list is in order by vertex id
        GEdgePtr prev, curr;
        prev = curr = G -> vertex[X].firstEdge;
        while (curr != NULL && Y > G -> vertex[curr -> child].id) {
           prev = curr;
           curr = curr -> nextEdge;
        }

        if (prev == curr) {
           ep -> nextEdge = G -> vertex[X].firstEdge;
           G -> vertex[X].firstEdge = ep;
        }
        else {
           ep -> nextEdge = curr;
           prev -> nextEdge = ep;
        }
     } //end addEdge

     GEdgePtr newGEdge(int c, int w) {
     //return a pointer to a new GEdge node
        GEdgePtr p = (GEdgePtr) malloc(sizeof (GEdge));;
        p -> child = c;
        p -> weight = w;
        p -> nextEdge = NULL;
        return p;
     }

     StackData newStackData(int n) {
        StackData temp;
        temp.nv = n;
        return temp;
     } //end newStackData

     void topologicalSort(Graph G) {
        void dfTopSort(Graph, Stack, int);
        Stack S = initStack();
        for (int h = 1; h <= G -> numV; h++) G -> vertex[h].colour = White;
        for (int h = 1; h <= G -> numV; h++)
           if (G -> vertex[h].colour == White) dfTopSort(G, S, h);
        printf("\nTopological sort: ");
        while (!empty(S)) printf("%d ", G -> vertex[pop(S).nv].id);
        printf("\n");
     } //end topologicalSort

     void dfTopSort(Graph G, Stack S, int s) {
        StackData newStackData(int);
        G -> vertex[s].colour = Gray;
        GEdgePtr edge = G -> vertex[s].firstEdge;
        while (edge != NULL) {
           if (G -> vertex[edge -> child].colour == Gray) {
              printf("\nGraph has a cycle: cannot sort\n");
              exit(1);
           }
           if (G -> vertex[edge -> child].colour == White)
                 dfTopSort(G, S, edge -> child);
           edge = edge -> nextEdge;
        }
        G -> vertex[s].colour = Black;
        push(S, newStackData(s));
     } //end dfTopSort

     void printRequirements(Graph G) {
        printf("The requirements are: \n\n");
        for (int h = 1; h <= G -> numV; h++) {
           int preID = G -> vertex[h].id;
           GEdgePtr p = G -> vertex[h].firstEdge;
           if (p == NULL) continue; //no requirement where this item comes first
           while (p != NULL) {
              printf("%d -> %d", preID, G -> vertex[p -> child].id);
              if (p -> nextEdge != NULL) printf(", "); //print comma except after last
              p = p -> nextEdge;
           }
           printf("\n");
        }
     } //end printRequirements
