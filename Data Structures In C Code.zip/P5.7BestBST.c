// Program P5.7
     #include <stdio.h>
     #include <string.h>
     #define MaxHeight 20

     typedef struct {
        int num;
     } NodeData;

     typedef struct treeNode {
        NodeData data;
        struct treeNode *left, *right;
     } TreeNode, *TreeNodePtr;

     typedef struct {
        TreeNodePtr root;
     } BinaryTree;

     int main() {
        void preOrder(TreeNodePtr);
        void inOrder(TreeNodePtr);
        void postOrder(TreeNodePtr);
        void insertBestBST(int, TreeNodePtr[]);
        TreeNodePtr finalizeBestBST(TreeNodePtr []);
        int n;
        TreeNodePtr lastNode[MaxHeight];

        for (n = 0; n < MaxHeight; n++) lastNode[n] = NULL;

        FILE * in = fopen("bestBST.in", "r");
        BinaryTree bst;

        while (fscanf(in, "%d", &n) == 1)
           insertBestBST(n, lastNode);

        bst.root = finalizeBestBST(lastNode);

        printf("\nThe pre-order traversal is: ");
        preOrder(bst.root);
        printf("\n\nThe in-order traversal is: ");
        inOrder(bst.root);
        printf("\n\nThe post-order traversal is: ");
        postOrder(bst.root);
        printf("\n\n");
        fclose(in);
     } // end main

     int getNodeLevel(int n) {
     //returns the highest power of 2 that divides n
        int level = 0;
        while (n % 2 == 0) {
           level++;
           n /= 2;
        }
        return level;
     }

     void insertBestBST(int n, TreeNodePtr lastNode[]) {
        int getNodeLevel(int);
        TreeNodePtr newTreeNode(NodeData);
        NodeData newNodeData(int);
        static int numNodes = 0;

        TreeNodePtr p = newTreeNode(newNodeData(n));
        numNodes++;
        int level = getNodeLevel(numNodes);
        // left pointer of new node is null if it is a leaf
        // else it's the entry in lastNode one level lower than new node
        if (level > 0) p -> left = lastNode[level-1];
        // if lastNode[level+1] exists and has a null right link,
        // set it to the new node
        if (lastNode[level+1] != NULL)
          if (lastNode[level+1] -> right == NULL)
             lastNode[level+1] -> right = p;
        // the current node is the last node processed at this level
        lastNode[level] = p;
     } //end insertBestBST

     TreeNodePtr newTreeNode(NodeData d) {
        TreeNodePtr p = (TreeNodePtr) malloc(sizeof(TreeNode));
        p -> data = d;
        p -> left = p -> right = NULL;
        return p;
     } //end newTreeNode

     NodeData newNodeData(int n) {
        NodeData temp;
        temp.num = n;
        return temp;
     } //end newNodeData

     TreeNodePtr finalizeBestBST(TreeNodePtr lastNode[]) {
       int m, n = MaxHeight - 1;
        // find the last entry in lastNode that is non-null
        // this is the root
        while (n > 0 && lastNode[n] == NULL) n--;
        TreeNodePtr root = lastNode[n];

        while (n > 0) {
           // find the highest node, n, whose right subtree is null;
           // this right child is set to the highest node in lastNode
           // that is not already in the left subtree of n.
          if (lastNode[n] -> right != NULL) n--;
           else {
             // need to check left(n) and all right subtrees from there
             TreeNodePtr tn = lastNode[n] -> left;
              m = n - 1;
              // check if the node, tn, in left subtree is the same as
              // the last node processed at that level, lastNode[m]
              while (m >= 0 && tn == lastNode[m]) {
                tn = tn -> right;
                 m--;
              }
              if (m >= 0) lastNode[n] -> right = lastNode[m];
              n = m;
           } //end else
        } //end while
        return root;
     } //end finalizeBST

     void visit(TreeNodePtr node) {
        printf("%d ", node -> data.num);
     } //end visit

     void preOrder(TreeNodePtr node) {
        void visit(TreeNodePtr);
        if (node != NULL) {
           visit(node);
           preOrder(node -> left);
           preOrder(node -> right);
        }
     } //end preOrder

     void inOrder(TreeNodePtr node) {
        void visit(TreeNodePtr);
        if (node != NULL) {
           inOrder(node -> left);
           visit(node);
           inOrder(node -> right);
        }
     } //end inOrder

     void postOrder(TreeNodePtr node) {
        void visit(TreeNodePtr);
        if (node != NULL) {
           postOrder(node -> left);
           postOrder(node -> right);
           visit(node);
        }
     } //end postOrder
