     NodePtr getLast(NodePtr top) {
        if (top == NULL) return NULL;
        while (top -> next != NULL)
           top = top -> next;
        return top;
     } //end getLast
