// Program P5.4
     #include <stdio.h>
     #include <string.h>
     #define MaxWordSize 20

     typedef struct {
        char word[MaxWordSize+1];
     } NodeData;

     typedef struct treeNode {
        NodeData data;
        struct treeNode *left, *right;
     } TreeNode, *TreeNodePtr;

     typedef struct {
        TreeNodePtr root;
     } BinaryTree;

     typedef struct {
        TreeNodePtr tnode;
        int meet;
     } StackData;

     #include <stack.h>

     int main() {
        TreeNodePtr buildTree(FILE *);
        void postOrder(TreeNodePtr);

        FILE * in = fopen("btree.in", "r");
        BinaryTree bt;
        bt.root = buildTree(in);

        printf("\nThe post-order traversal is: ");
        postOrder(bt.root);
        printf("\n\n");
        fclose(in);
     }

     void postOrder(TreeNodePtr root) {
        StackData newStackData(TreeNodePtr, int);
        Stack S = initStack();
        TreeNodePtr curr = root;
        int finished = 0;
        while (!finished) {
           while (curr != NULL) {
              push(S, newStackData(curr, 0));
              curr = curr -> left;
           }
           if (empty(S)) finished = 1;
           else {
              StackData temp = pop(S);
              if (temp.meet == 1) printf("%s ", temp.tnode -> data.word);
              else {
                 push(S, newStackData(temp.tnode, 1));
                 curr = temp.tnode -> right;
              }
           } //end else
        } //end while (!finished)
     } //end postOrder

     StackData newStackData(TreeNodePtr tnp, int n) {
        StackData temp;
        temp.tnode = tnp;
        temp.meet = n;
        return temp;
     } //end newStackData

     TreeNodePtr buildTree(FILE * in) {
        char str[MaxWordSize+1];
        fscanf(in, "%s", str);
        if (strcmp(str, "@") == 0) return NULL;
        TreeNodePtr p = (TreeNodePtr) malloc(sizeof(TreeNode));
        strcpy(p -> data.word, str);
        p -> left = buildTree(in);
        p -> right = buildTree(in);
        return p;
     } //end buildTree
