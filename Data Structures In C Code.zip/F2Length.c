     int length(char string[]) {  //array version
        int n = 0;
        while (string[n] != '\0') n++;
        return n;
     }

     int length(char *strPtr) {  // string pointer version
        int n = 0;
        while (*strPtr != '\0') {
          n++;
          strPtr++;
        }
        return n;
     }

     int length(char *strPtr) { // short pointer version
        int n = 0;
        while (*strPtr++ != '\0') n++;
        return n;
     }
