     #include <stdio.h>
     int main() {
        void dprint(double *), vprint(void *);
        int n = 375;
        double d = 2.71865;
        dprint(&d); //int pointer passed
        vprint(&d); //double pointer passed
     }

     void dprint(double *p) {
        printf("%0.3f\n", *p); //print to 3 decimal places
     }

     void vprint(void *p) {     //this won�t work
        printf("%0.3f\n", *p);
     }
