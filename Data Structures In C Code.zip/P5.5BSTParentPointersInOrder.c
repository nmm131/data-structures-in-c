// Program P5.5
     #include <stdio.h>
     #include <string.h>
     #define MaxWordSize 20

     typedef struct {
        char word[MaxWordSize+1];
     } NodeData;

     typedef struct treeNode {
        NodeData data;
        struct treeNode *left, *right, *parent;
     } TreeNode, *TreeNodePtr;

     typedef struct {
        TreeNodePtr root;
     } BinaryTree;

     int main() {
        TreeNodePtr newTreeNode(NodeData);
        NodeData newNodeData(char []);
        TreeNodePtr findOrInsert(BinaryTree, NodeData);
        void inOrder(TreeNodePtr);

        char word[MaxWordSize+1];

        FILE * in = fopen("words.in", "r");

        BinaryTree bst;
        bst.root = NULL;

        while (fscanf(in, "%s", word) == 1)
           if (bst.root == NULL) bst.root = newTreeNode(newNodeData(word));
           else findOrInsert(bst, newNodeData(word));

        printf("\nThe in-order traversal is: ");
        inOrder(bst.root);
        printf("\n\n");
        fclose(in);
     } // end main

     TreeNodePtr newTreeNode(NodeData d) {
        TreeNodePtr p = (TreeNodePtr) malloc(sizeof(TreeNode));
        p -> data = d;
        p -> left = p -> right = p -> parent = NULL;
        return p;
     } //end newTreeNode

     NodeData newNodeData(char str[]) {
        NodeData temp;
        strcpy(temp.word, str);
        return temp;
     } //end newNodeData

     TreeNodePtr findOrInsert(BinaryTree bt, NodeData d) {
     //Searches the tree for d; if found, returns a pointer to the node.
     //If not found, d is added and a pointer to the new node returned.
     //The parent field of d is set to point to its parent.

        TreeNodePtr newTreeNode(NodeData), curr, node;
        int cmp;
        if (bt.root == NULL) {
           node = newTreeNode(d);
           node -> parent = NULL;
           return node;
        }
        curr = bt.root;
        while ((cmp = strcmp(d.word, curr -> data.word)) != 0) {
           if (cmp < 0) { //try left
              if (curr -> left == NULL) {
                 curr -> left  = newTreeNode(d);
                 curr -> left -> parent = curr;
                 return curr -> left;
              }
              curr = curr -> left;
           }
           else { //try right
              if (curr -> right == NULL)  {
                 curr -> right = newTreeNode(d);
                 curr -> right -> parent = curr;
                 return curr -> right;
              }
              curr = curr -> right;
           } //end else
        } //end while
        //d is in the tree; return pointer to the node
        return curr;
     } //end findOrInsert

     void inOrder(TreeNodePtr node) {
        TreeNodePtr inOrderSuccessor(TreeNodePtr);
        if (node == NULL) return;
        //find first node in in-order
        while (node -> left != NULL) node = node -> left;
        while (node != NULL) {
           printf("%s ", node -> data.word);
           node = inOrderSuccessor(node);
        }
     } //end inOrder

     TreeNodePtr inOrderSuccessor(TreeNodePtr node) {
        if (node -> right != NULL) {
           node = node -> right;
           while (node -> left != NULL) node = node -> left;
           return node;
        }
        //node has no right subtree; search for the lowest ancestor of the
        //node for which the node is in the ancestor�s left subtree
        //return NULL if there is no successor (node is the last in in-order)
        TreeNodePtr parent = node -> parent;
        while (parent != NULL && parent -> right == node) {
           node = parent;
           parent = node -> parent;
        }
        return parent;
     } //end inOrderSuccessor
